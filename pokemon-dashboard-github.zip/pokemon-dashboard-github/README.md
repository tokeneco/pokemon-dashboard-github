# Pokemon Card Investing Dashboard

Single-file HTML dashboard for viewing a Pokémon card investing command center in any browser.

## Files
- `index.html` — standalone dashboard
- `vercel.json` — optional Vercel config
- `.gitignore` — basic ignore rules

## Run locally
Just open `index.html` in your browser.

## Deploy to Vercel
1. Push this folder to GitHub.
2. Import the repo into Vercel.
3. Deploy as a static site.

## Notes
This single-file version is a standalone viewer. It does not include the live eBay backend proxy.
